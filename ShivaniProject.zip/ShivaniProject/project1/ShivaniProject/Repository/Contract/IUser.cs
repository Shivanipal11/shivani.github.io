﻿using ShivaniProject.Models.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ShivaniProject.Utils.Enums;

namespace ShivaniProject.Repository.Contract
{
     public interface IUser
    {
        SignUp Register(SignUp model);
        AuthoEnum AuthenticateUser(SignIn model);
        VerifyAccountEnum VerifyAccount(string otp);
        bool UpdateProfile(string Email, string path);

    }
}
