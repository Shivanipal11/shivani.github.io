﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ShivaniProject.Models;
using ShivaniProject.Repository.Contract;
using ShivaniProject.Models.ViewModel;
using ShivaniProject.Utils.Enums;
using System.Net.Mail;

namespace ShivaniProject.Repository.Services
{
    public class UserService:IUser
    {
        private EmpDbContext dbContext;
        public UserService(EmpDbContext _dbContext)
        {
            dbContext = _dbContext;
        }
        
          public SignUp Register(SignUp model)
        {
            if(dbContext.user.Any(e =>e.Email ==model.Email))
            {
                return null;
            }
            else
            {
                var u = new Users() { 
                    FirstName = model.FirstName, 
                    LastName = model.LastName, 
                    Email = model.Email,
                    Password=model.Password,
                    IsActive=true,
                    IsVerified=false
                };
                dbContext.user.Add(u);
                string otp = GenerateOTP();
                SendMail(model.Email, otp);
                var Vaccount = new VerifyAccount()
                {
                    UserEmail = model.Email,
                    OTP = otp,
                    SendTime = DateTime.Now
                };
                dbContext.VerifyAccounts.Add(Vaccount);
                dbContext.SaveChanges();
                return model;

            }
        }

        private void SendMail(string email, string otp)
        {
            MailMessage mail = new MailMessage();
            mail.To.Add(email);
            mail.From = new MailAddress("Shivanipal751@gmail.com");
            mail.Subject = "Verify your Account";
            string body =$"your otp is :{otp}</b> Thanks for choosing us";
            mail.Body = body;
            mail.IsBodyHtml = true;
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smpt.gmail.com";
            smtp.Port = 571;
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = new System.Net.NetworkCredential("Shivanipal751@gmail.com","57124");
            smtp.EnableSsl = true;
            smtp.Send(mail);
        }

        private string GenerateOTP()
        {
            var chargs = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            var random = new Random();
            var list = Enumerable.Repeat(0, 9).Select(e => chargs[random.Next(chargs.Length)]);
            var r = string.Join("", list);
            return r;
        }

        public AuthoEnum AuthenticateUser(SignIn model)
        {
            var user = dbContext.user.SingleOrDefault(e => e.Email==model.Email && e.Password == model.Password);
            if (user == null)
            {
                return AuthoEnum.FAILED;
            }
            else if (user.IsVerified == true)
            {
                return AuthoEnum.SUCCESS;
            }
            else if (user.IsVerified==false)
            {
                return AuthoEnum.NOTVERIFIED;
            }    
            else
            {
                return AuthoEnum.NOTACTIVE;
            }
                
            
        }




        public VerifyAccountEnum VerifyAccount1(string otp)
        {
            if (dbContext.VerifyAccounts.Any(e => e.OTP == otp))
            {
                var account = dbContext.VerifyAccounts.SingleOrDefault(e => e.OTP == otp);
                var user = dbContext.user.SingleOrDefault(e => e.Email == account.UserEmail);
                user.IsVerified = true;
                dbContext.VerifyAccounts.Remove(account);
                dbContext.user.Update(user);
                dbContext.SaveChanges();
                return VerifyAccountEnum.OTPVERIFIED;
            }
            else
            {
                return VerifyAccountEnum.INVALIEDOTP;
            }
        }

        public bool UpdateProfile(string Email, string path)
        {
            var Shivani = dbContext.user.SingleOrDefault(e =>e.Email == Email);
            Shivani.Image = path;
            dbContext.user.Update(Shivani);
            dbContext.SaveChanges();
            return true;
        }

        public VerifyAccountEnum VerifyAccount(string otp)
        {
            throw new NotImplementedException();
        }
    }
}
