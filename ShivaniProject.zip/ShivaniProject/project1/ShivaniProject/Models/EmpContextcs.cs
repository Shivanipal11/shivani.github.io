﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace ShivaniProject.Models
{
    public class EmpDbContext : DbContext
    {
        public EmpDbContext(DbContextOptions<EmpDbContext> options) : base(options) { }
        public DbSet<Users> user { get; set; }
        public DbSet<VerifyAccount> VerifyAccounts { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Department> Departments  { get; set; }
    }
}
